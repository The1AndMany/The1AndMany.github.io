KAI V0.4 Alpha
Written and programmed by Samuel Henthorne
Please visit www.lowrezlabs.net for more info
---------------------------------------------------------------------
Disclaimer:
I cannot be held responsible for anything that happens to you or your ship while using this program, including (but not limited to) bounties, fines, ship loss, or cargo loss. USE AT YOUR OWN RISK!
---------------------------------------------------------------------
Installation instructions:

Note: These instructions assume you have VoiceAttack installed in the default location

1. Extract "KAI Sounds" folder to C:\Program Files (x86)\VoiceAttack\Sounds
	This should result in the new directory C:\Program Files (x86)\VoiceAttack\Sounds\KAI Sounds
	DO NOT just extract the contents of EDAI Sounds; extract the folder itself
2. Extract "KAI.2.0.binds" to C:\Users\<your username>\AppData\Local\Frontier Developments\Elite Dangerous\Options\Bindings
	The appdata folder is hidden by default. Either turn hidden files visible in your "view" menu or search for "%localappdata%" in the Start menu (or Cortana on Windows 10)
	The .binds file is based off a combination of the keyboard\mouse and "Default Context" binding presets, with a few keys added to increase functionality. You don't have to install and use these bindings and can use one of the presets it's based off of instead, but some commands (like "supercruise") won't work
3. Install EDDI
	Available at http://www.mcdee.net/elite/EDDI.exe
	This version of KAI was built to work with EDDI version 2.3.0
4. Extract "kai.json" to C:\Users\<your username>\AppData\Roaming\EDDI\personalities
	The appdata folder is hidden by default. Either turn hidden files visible in your "view" menu or search for "%appdata%" in the Start menu (or Cortana on Windows 10)
5. Configure EDDI as follows:
	a. Log into the Companion App
	b. Set your preferred TTS engine and settings (optional)
	c. Fill in details on your commander and ships (optional)
	d. Log into the EDSM responder (optional)
	e. Set the speech responder to use the KAI personality
6. Import "KAI (<Version>)-Profile.vap" to Voice Attack
	Replace <Version> with whatever version you're installing
7. Open Voice Attack and Elite Dangerous
8. Change control bindings to the new "KAI" default
---------------------------------------------------------------------
Update instructions:
Note: Updating from Alpha 0.3 or earlier requires a fresh install. Please follow the installation instructions above.
Updating from Alpha 0.4 or later:
1. Check Changelog.txt to see what needs to be updated for every update since your current install
	a. If commands need to be updated, import the new .vap file and run the "reboot" command
	b. If sounds need to be updated, overwrite the old "KAI Sounds" folder with the new one
	c. If bindings need to be updated, import the .bindings file
		* Don't forget to set ED to use the KAI preset
	d. If the personality needs to be updated, overwrite the .json file with the new one
---------------------------------------------------------------------
Usage instructions:
1. Make sure your microphone is plugged in and properly set up
	Headset microphones work better for voice recognition
2. Keep Voice Attack running in the background with the KAI profile loaded while playing Elite Dangerous
3. Say one of the commands (Reference sheet included, see AlphaCommands.txt)
4. Voice Attack will perform the action(s) associated with the command
---------------------------------------------------------------------
Optional features: (see Customization.txt for instructions on how to change these)
* Ignore Voice Attack's "listening" toggle when a command is prefixed with "computer" (enabled by default)
* Relay passive information based on in-game events (enabled by default)
* Report info about a system when jumping to it (disabled by default)
* Set throttle to 0% when exiting witchspace (enabled by default)
* Retract landing gear upon liftoff/undocking (enabled by default)
* Set throttle to 100% and boost upon exiting a station's no-fire zone (enabled by default)
---------------------------------------------------------------------
Upcoming features:
* More commands
* Voice acting!
* A backstory (No, seriously)
---------------------------------------------------------------------
License information:
All files in "KAI Sounds\Beeps" are public domain
All other files are provided under the Creative Commons Attribution ShareAlike 4.0 International license, which can be found at http:\\creativecommons.org\licenses\by-sa\4.0\