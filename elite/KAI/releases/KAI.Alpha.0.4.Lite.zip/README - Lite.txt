KAI V0.4 Alpha (Lite version)
Written and programmed by Samuel Henthorne
Please visit www.lowrezlabs.net for more info
---------------------------------------------------------------------
Disclaimer:
I cannot be held responsible for anything that happens to you or your ship while using this program, including (but not limited to) bounties, fines, ship loss, or cargo loss. USE AT YOUR OWN RISK!
---------------------------------------------------------------------
Installation instructions:

Note: These instructions assume you have VoiceAttack installed in the default location

1. Extract "KAI Sounds" folder to C:\Program Files (x86)\VoiceAttack\Sounds
	This should result in the new directory C:\Program Files (x86)\VoiceAttack\Sounds\KAI Sounds
	DO NOT just extract the contents of EDAI Sounds; extract the folder itself
2. Extract "KAI.1.8.binds" to C:\Users\<your username>\AppData\Local\Frontier Developments\Elite Dangerous\Options\Bindings
	The appdata folder is hidden by default. Either turn hidden files visible in your "view" menu or search for "%localappdata%" in the Start menu (or Cortana on Windows 10)
	The .binds file is based off the default keyboard\mouse bindings, but with a few keys added to increase functionality. You don't have to install and use these bindings and can use the default keyboard\mouse bindings instead, but some commands (like "supercruise") won't work
3. Import "KAI (<Version>)-Profile.vap" to Voice Attack
	Replace <Version> with whatever version you're installing
	There should be two .vap files in this download. The one with a version number ending in "-S" has Silent Mode enabled by default.
		This is meant for CMDR's who prefer the in-game ship AI voice and don't want to disable it, or who have disabled it and prefer the silence.
4. Open Voice Attack and Elite Dangerous
5. Change control bindings to the new "KAI" default
---------------------------------------------------------------------
Update instructions:

Note: If you're updating from Alpha 0.2 or earlier, the old sounds folder will be called "EDAI Sounds". In this case, delete EDAI Sounds and replace it with KAI Sounds. The commands will automatically adjust to the new folder name when you update them.

0. Check to make sure you don't already have the latest version (www.lowrezlabs.net)
1. Download the latest version
2. Check the changelog to see what's different
	Going forward, future versions will have an indicator on the Changelog entry saying what you need to change. Check that indicator for every update since the old one you were using
	a. The changelog will always say to update the commands, so import the new .vap file
		Once it's imported, you can delete the old profile and just start using the new one
		The variable keypresses will be reset, so you'll have to rebind your custom keybindings if you have them. See Customization.txt for instructions.
	b. If the changelog says to update the sounds, replace the old sounds folder with the new one
	c. If the changelog says to update the bindings...
		A. if you're not using custom keybinds, replace the old .binds file with the new one and set ED to use the new default bindings
		B. if you are using custom keybinds, ensure that your custom bindings profile contains all variable keypresses present in the "acknowledge" command, and that they match
---------------------------------------------------------------------
Usage instructions:
1. Make sure your microphone is plugged in and properly set up
	Headset microphones work better for voice recognition
2. Keep Voice Attack running in the background with the KAI profile loaded while playing Elite Dangerous
3. Say one of the commands (Reference sheet included, see AlphaCommands.txt)
4. Voice Attack will perform the action(s) associated with the command
---------------------------------------------------------------------
Optional features: (see Customization.txt for instructions on how to change these)
* Ignore Voice Attack's "listening" toggle when a command is prefixed with "computer"
* (That's the only one for now, but more are available in the full version)
---------------------------------------------------------------------
Upcoming features:
* More commands
* Voice acting!
* A backstory (No, seriously)
---------------------------------------------------------------------
License information:
All files in "KAI Sounds\Beeps" are public domain
All other files are provided under the Creative Commons Attribution ShareAlike 4.0 International license, which can be found at http:\\creativecommons.org\licenses\by-sa\4.0\