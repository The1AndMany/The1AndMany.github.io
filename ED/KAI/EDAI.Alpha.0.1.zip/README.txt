EDAI V0.1 Alpha
Written and programmed by Samuel Henthorne
Please visit sites.google.com/site/the1andmanyistaken/ed-ai for more info
---------------------------------------------------------------------
Disclaimer:
I cannot be held responsible for anything that happens to you or your ship while using this program, including (but not limited to) bounties, fines, ship loss, or cargo loss. USE AT YOUR OWN RISK!
---------------------------------------------------------------------
Installation instructions:
1. Extract "EDAI Sounds" folder to C:/Program Files (x86)/VoiceAttack/Sounds
	This should result in the new directory C:/Program Files (x86)/VoiceAttack/Sounds/EDAI Sounds
	DO NOT just extract the contents of EDAI Sounds; extract the folder itself
2. Copy "EDAI.1.8.binds" to C:\Users\<your username>\AppData\Local\Frontier Developments\Elite Dangerous\Options\Bindings
3. Import "EDAI-Profile.vap" to Voice Attack
4. Open Voice Attack and Elite Dangerous
5. Change control bindings to the new "EDAI" default
---------------------------------------------------------------------
Usage instructions:
1. Make sure your microphone is plugged in and properly set up
	Headset microphones work better for voice recognition
2. Keep Voice Attack running in the background with the EDAI profile loaded while playing Elite Dangerous
3. Say one of the commands (Reference sheet included with download)
4. Voice Attack will perform the action associated with the command
---------------------------------------------------------------------
Optional features: (All disableable)
Make a noise every time this profile is loaded in Voice Attack
Ignore Voice Attack's "listening" toggle when a command is prefixed with "computer"
---------------------------------------------------------------------
Upcoming features:
* More commands
* Confirmations for sensitive commands
* Custom binding instructions
* Voice acting!
* A backstory. Yeah.
---------------------------------------------------------------------
License information:
All files in "EDAI Sounds/Beeps" are public domain
All other files are provided under the Creative Commons Attribution ShareAlike 4.0 International license, which can be found at http://creativecommons.org/licenses/by-sa/4.0/