The files in this folder were created with the intent of mimicking what a Pilot's Federation License might look like in Elite: Dangerous. The instructions below detail how to best customize it for your own CMDR.

Note: The image this file generates is too tall for use on the official Elite: Dangerous forums. If enough interest is shown, I'll look into re-arranging the elements to allow for a shorter result. Until then, using the Scale Image tool just before exporting will resize the result to any size you need, but may result in illegible text or distorted images.

Prerequestites:
* This file requires a photo-editing program called GIMP. This program is freely available at https://www.gimp.org/. PHOTOSHOP CANNOT OPEN THIS FILE!
* You will also need the following fonts, which are available at their corresponding website:
	* Daniel - http://www.dafont.com/daniel.font
	* Euro Caps - http://www.dafont.com/euro-caps.font
	* Sintony - https://fonts.google.com/specimen/Sintony
	* Telegrama - https://www.fontsquirrel.com/fonts/telegrama
* The information for most of the customization prompts can be found in-game, but you'll have to be willing to make some parts up because there's no way to tell in-game

Instructions:
0. Ensure that you have met all of the prerequestites above
1. Open Template.xcf in GIMP
2. Replace the image on the left with one of your own CMDR that is 254px or less on all sides
	Note: I recommend screenshotting your Holo-Me
3. Replace the following text, being sure to maintain the listed font size:
	a. CMDR Name (16px)
	b. Birth Date (14px)
	c. Place of Birth (16px)
	d. Preferred Role (16px)
	e. Signature (18px)
		Note: Feel free to use any handwriting font you prefer
	Note: This is easiest done by right-clicking each text layer and choosing Text Tool from the menu, but deleting the existing text before typing more will reset text size to whatever your Text tool is set to use (18px by default)
4. Make the layers that correspond with your current ED Rankings visible, and hide the rest of the Official Rankings layers
5. Make the layer that corresponds with your affiliated superpower (or lack thereof) visible, and hide the rest of the Superpower layers
6. (Optional, but advanced) Replace the "Coriolis" layer with any background you like, or just delete the layer altogether
	Note: Be sure to leave the Background and Holo-overlay layers as they are
7. Perform sanity checks, and make sure everything looks nice
8. Export the image (File > Export, or Ctrl+E)